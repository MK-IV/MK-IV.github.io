import installer
import time
import os
import sys
import xbmc

Local=xbmc.translatePath('special://home/addons/plugin.program.mkiv')

if not os.path.exists(Local):
	installer.Install()
	time.sleep(1)
	installer.Enable()
	time.sleep(1)
	installer.Enable()
	xbmc.executebuiltin('RunAddon(plugin.program.mkiv)')
else:
	pass

if os.path.exists(Local):
	installer.RemoveInstaller()