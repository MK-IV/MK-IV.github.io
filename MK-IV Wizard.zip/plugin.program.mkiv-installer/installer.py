import xbmc
import os
import downloader
import extract
import time
import shutil
import sqlite3

Addons=xbmc.translatePath('special://home/addons/')
lib=xbmc.translatePath('special://home/addons/packages/plugin.program.mkiv-master.zip')
Local=xbmc.translatePath('special://home/addons/plugin.program.mkiv')
Master=xbmc.translatePath('special://home/addons/plugin.program.mkiv-master')
Installer=xbmc.translatePath('special://home/addons/plugin.program.mkiv-installer')
Addons27=xbmc.translatePath('special://home/userdata/Database/Addons27.db')

def Install():
	try:
		os.remove(lib)
	except:
		pass
	downloader.download('https://github.com/MK-IV/plugin.program.mkiv/archive/master.zip', lib)
	extract.all(lib,Addons)
	time.sleep(.5)
	try:
		os.remove(lib)
	except:
		pass
	try:    
		os.rename(Master,Local)
	except: pass

def Enable():
	try:
		conn = sqlite3.connect(Addons27)
		cursor = conn.cursor()

		sql = """
		UPDATE installed 
		SET enabled = '1' 
		WHERE addonID = 'plugin.program.mkiv'
		"""
		cursor.execute(sql)
		conn.commit()
		time.sleep(1)
		conn = sqlite3.connect(Addons27)
		cursor = conn.cursor()

		sql = """
		UPDATE installed 
		SET enabled = '0' 
		WHERE addonID = 'plugin.program.mkiv-installer'
		"""
		cursor.execute(sql)
		conn.commit()
		time.sleep(1)
		xbmc.executebuiltin('UpdateLocalAddons')
	except: pass

def RemoveInstaller():
	try:
		shutil.rmtree(Installer)
	except: pass