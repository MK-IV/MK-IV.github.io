import installer
import time
import os
import sys

Local=xbmc.translatePath('special://home/addons/plugin.program.mkiv')

if not os.path.exists(Local):
	installer.Install()
	time.sleep(1)
	installer.Enable()
	time.sleep(1)
	installer.Enable()
else:
	pass

if os.path.exists(Local):
	installer.RemoveInstaller()